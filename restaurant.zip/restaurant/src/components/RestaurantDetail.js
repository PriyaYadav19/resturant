import React, { Component } from 'react';
import {Text,View,Stylesheet,} from 'react';
class RestaurantDetail extends React.Component{
    constructor(){
        super();
        this.state={
        }
    }

    render() {
        return(
            <div >
                <h1>Restaurant Detail</h1>
            </div >
        )
    }
}
export  default  RestaurantDetail;