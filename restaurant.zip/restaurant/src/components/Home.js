import React, { Component } from 'react';
import {Text,View,Stylesheet,} from 'react';
class Home extends React.Component{
    constructor(){
        super();
        this.state={
        }
    }

    render() {
        return(
            <div >
                <h1>Home</h1>
            </div >
        )
    }
}
export  default Home;