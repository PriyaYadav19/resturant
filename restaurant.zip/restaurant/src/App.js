import React, { Component } from 'react';
//import logo from './logo.svg';
import './App.css';
import RestaurantCreate from './components/RestaurantCreate';
import RestaurantDetail from './components/RestaurantDetail';
import RestaurantList  from './components/RestaurantList';
import RestaurantUpdate from "./components/RestaurantUpdate";
import RestaurantSearch from "./components/RestaurantSearch";
import Home from "./components/Home";
import {Navbar,Nav,NavbarBrand,NavDropdown,NavItem,NavLink,Form,Button,FormControl} from  "react-bootstrap";
import {
  BrowserRouter as Router,
  Route,
  Link
} from "react-router-dom";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCoffee,faEdit,faTrash,faHome,faPlus,faSearch ,faList} from '@fortawesome/free-solid-svg-icons'

class App extends Component{
  constructor(){
    super();
    this.state={
      users:null
    }
  }

  render() {
    return(
        <div className="App">
          <h1>FOOD PLAZA</h1>
          <Router>
              <Navbar bg="#007BFF" expand="lg">
                  <Navbar.Brand href="#home">Resto</Navbar.Brand>
                  <Navbar.Toggle aria-controls="basic-navbar-nav" />
                  <Navbar.Collapse id="basic-navbar-nav">
                      <Nav className="mr-auto">
                          <Nav.Link href="#home"><Link to="/"><FontAwesomeIcon icon={faHome}/>Home</Link>
                              </Nav.Link>
                          <Nav.Link href="#link"><Link to="/create"><FontAwesomeIcon icon={faPlus}/>Create</Link></Nav.Link>
                          <Nav.Link href="#home"><Link to="/list"><FontAwesomeIcon icon={faList}/>List</Link></Nav.Link>
                          <Nav.Link href="#home"><Link to="/search"><FontAwesomeIcon icon={faSearch}/>Search</Link></Nav.Link>
                          <Nav.Link href="#home"><Link to="/update"><FontAwesomeIcon icon={faEdit}/>Update</Link></Nav.Link>

                          <NavDropdown title="Dropdown" id="basic-nav-dropdown">
                              <NavDropdown.Item href="#action/3.1">Action</NavDropdown.Item>
                              <NavDropdown.Item href="#action/3.2">Another action</NavDropdown.Item>
                              <NavDropdown.Item href="#action/3.3">Something</NavDropdown.Item>
                              <NavDropdown.Divider />
                              <NavDropdown.Item href="#action/3.4">Separated link</NavDropdown.Item>
                          </NavDropdown>
                      </Nav>
                      <Form inline>
                          <FormControl type="text" placeholder="Search" className="mr-sm-2" />
                          <Button variant="outline-success">Search</Button>
                      </Form>
                  </Navbar.Collapse>
              </Navbar>



              <Route path="/create">
                <RestaurantCreate/>
              </Route>
              <Route path="/detail">
                <RestaurantDetail />
              </Route>
              <Route path="/list">
                <RestaurantList/>
              </Route>
              <Route path="/search">
                <RestaurantSearch/>
            </Route>
              <Route path="/update/:id"
                     render={props=> (
                        <RestaurantUpdate {...props} />


                         )} >


              </Route>

              <Route  exact path="/">
                <Home/>
              </Route>

          </Router>
        
        </div >
    )
  }
}

export default App;
